
import json
import argparse

class Report:
    def __init__(self):
        pass

    def compare_line(self, reference, candidate): # reference 标注
        ref_len = len(reference.replace(' ', ''))
        can_len = len(candidate.replace(' ', ''))

        # if ref_len != can_len:
        # print('error len')
        # return None

        ref_words = reference.split()
        can_words = candidate.split()

        ref_words_len = len(ref_words)
        can_words_len = len(can_words)

        ref_index = []
        index = 0
        for word in ref_words:
            word_index = [index]
            index += len(word)
            word_index.append(index)
            ref_index.append(word_index)

        can_index = []
        index = 0
        for word in can_words:
            word_index = [index]
            index += len(word)
            word_index.append(index)
            can_index.append(word_index)

        tmp = [val for val in ref_index if val in can_index]
        acc_word_len = len(tmp)

        return ref_words_len, can_words_len, acc_word_len


def test_value(ground_truth_path, prediction_path):
    report = Report()

    # fref = open('data/%s.txt' % test_set, 'r', encoding='utf8')
    # fcan = open('result/%s.%s' % (test_set, name), 'r', encoding='utf8')
    fref = open(ground_truth_path, 'r', encoding='utf8')
    fcan = open(prediction_path, 'r', encoding='utf8')

    reference_all = fref.readlines()
    candidate_all = fcan.readlines()
    fref.close()
    fcan.close()

    ref_count = 0
    can_count = 0
    acc_count = 0
    for reference, candidate in zip(reference_all, candidate_all):
        reference = reference.strip()
        candidate = candidate.strip()

        ref_words_len, can_words_len, acc_word_len = report.compare_line(reference, candidate)
        ref_count += ref_words_len
        can_count += can_words_len
        acc_count += acc_word_len

    P = acc_count / can_count * 100
    R = acc_count / ref_count * 100
    F1 = (2 * P * R) / (P + R)

    # print(name)
    # print('准确率', P)
    # print('召回率', R)
    # print('F1', F1)

    return  P, R, F1

def main(args):
    ground_truth = args.test_private_file
    prediction = args.prediction_file
    P, R, F1 = test_value(ground_truth, prediction)
    dic = {'精准率': "%.2f%%" % P, '召回率': "%.2f%%" % R, 'F1': "%.2f" % F1}
    js = json.dumps(dic, sort_keys=True, indent=4, separators=(',', ':'), ensure_ascii=False)
    print(js)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('prediction_file', type=str, help='path of prediction file')
    parser.add_argument('test_private_file', type=str, help='path of ground truth file')
    args = parser.parse_args()
    main(args)