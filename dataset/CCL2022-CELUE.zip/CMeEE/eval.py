# encoding=utf-8
import sys
import json

def load_test_dict(filename):
    # 创建正确答案字典
    golden_dict={}
    with open(filename) as input_data:
        json_content = json.load(input_data)
        for block in json_content:
            text = block['text']
            golden_dict[text] = set()
            for entity in block['entities']:
                start_idx = entity['start_idx']
                end_idx = entity['end_idx']
                entity_type = entity['type']
                golden_dict[text].add(tuple([start_idx, end_idx, entity_type]))

        return golden_dict


def list2dic(ent_lst):
    temp_dic = {}
    for ent in ent_lst:
        if ent[2] not in temp_dic:
            temp_dic[ent[2]] = [ent]
        elif ent not in temp_dic[ent[2]]:
            temp_dic[ent[2]].append(ent)
    p_lst = list(temp_dic.keys())
    return temp_dic, p_lst

def calc_micro(predict_filename, golden_filename):
    """ 微平均 micro-F1
    calculate precision, recall, f1
        计算整体微平均的 precision, recall, f1
    """
    golden_dict = load_test_dict(golden_filename)
    predict_dict = load_test_dict(predict_filename)
    correct_sum, predict_sum, recall_sum, recall_correct_sum = 0.0, 0.0, 0.0, 0.0
    for sent in golden_dict:
        #
        golden_lst = golden_dict[sent]
        predict_lst = predict_dict[sent]
        recall_sum += len(golden_lst)
        predict_sum += len(predict_lst)
        for entity in predict_lst:
            if entity in golden_lst:
                correct_sum += 1
        for entity in golden_lst:
            if entity in predict_lst:
                recall_correct_sum += 1
    # sys.stderr.write('correct entity num = {}\n'.format(correct_sum))
    # sys.stderr.write('submitted entity num = {}\n'.format(predict_sum))
    # sys.stderr.write('golden set entity num = {}\n'.format(recall_sum))
    # sys.stderr.write('submitted recall entity num = {}\n'.format(recall_correct_sum))
    precision = correct_sum / predict_sum if predict_sum > 0 else 0.0
    recall = recall_correct_sum / recall_sum if recall_sum > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) \
            if precision + recall > 0 else 0.0
    precision = round(precision, 4)
    recall = round(recall, 4)
    f1 = round(f1, 4)
    t_lst = ['micro—all', correct_sum, predict_sum, recall_sum, recall_correct_sum, precision, recall, f1]
    return t_lst

if __name__ == '__main__':
    golden_filename = sys.argv[1]
    predict_filename = sys.argv[2]

    ret_macro = calc_micro(predict_filename, golden_filename)
    print("ret_micro", ret_macro)
